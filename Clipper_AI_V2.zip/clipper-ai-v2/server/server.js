const express = require("express");
const path = require("path");
const OpenAI = require("openai");

const app = express();
app.use(express.json({limit:"2mb"}));
app.use(express.static(path.join(__dirname,"../frontend")));

const port = process.env.PORT || 3000;
const client = process.env.OPENAI_API_KEY ? new OpenAI({apiKey:process.env.OPENAI_API_KEY}) : null;

app.post("/api/analyze", async (req,res)=>{
  const url = String(req.body?.youtube_url || "").trim();
  if(!url) return res.status(400).json({error:"URL video wajib diisi."});
  if(!client) return res.status(503).json({error:"OPENAI_API_KEY belum dikonfigurasi di server."});

  // V2 intentionally does not download/bypass YouTube protections.
  // The next backend module should receive a lawful transcript for the supplied video.
  return res.status(501).json({
    error:"Mesin transkrip belum terhubung. Backend AI sudah siap menerima transcript pada tahap berikutnya.",
    next_step:"Tambahkan transcript provider yang berwenang, lalu kirim transcript ke analyzer."
  });
});

app.get("/api/health",(req,res)=>res.json({ok:true,service:"clipper-ai-v2"}));
app.listen(port,()=>console.log(`Clipper AI V2 running on port ${port}`));
