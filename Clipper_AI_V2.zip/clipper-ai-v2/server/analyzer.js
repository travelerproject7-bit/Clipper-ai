const OpenAI = require("openai");

async function analyzeTranscript(transcript) {
  if (!process.env.OPENAI_API_KEY) throw new Error("OPENAI_API_KEY belum dikonfigurasi.");
  const client = new OpenAI({apiKey:process.env.OPENAI_API_KEY});

  const response = await client.responses.create({
    model: process.env.OPENAI_MODEL || "gpt-5-mini",
    input: [
      {role:"system",content:"You are a short-form video editor. Find self-contained, engaging moments from a timestamped transcript. Return only structured JSON."},
      {role:"user",content:`Analyze this timestamped transcript and find up to 10 strong short-video moments. Prefer complete thoughts, strong hooks, useful insights, emotional or surprising statements, and clear context. Avoid clips that start/end mid-sentence.\n\n${transcript}`}
    ],
    text: {
      format: {
        type:"json_schema",
        name:"clip_candidates",
        strict:true,
        schema:{
          type:"object",
          properties:{
            clips:{type:"array",items:{type:"object",properties:{
              start:{type:"string"},end:{type:"string"},score:{type:"integer",minimum:0,maximum:100},
              hook:{type:"string"},reason:{type:"string"}
            },required:["start","end","score","hook","reason"],additionalProperties:false}}
          },
          required:["clips"],additionalProperties:false
        }
      }
    }
  });
  return JSON.parse(response.output_text);
}
module.exports={analyzeTranscript};
